//
//  ContentView.swift
//  map_pin
//
//  Created by Amos Gyamfi on 3.1.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var squash_and_tretch = false
    @State private var jump = false
    @State private var rotate = false
    @State private var displayRipple = false
      @State private var dismissRipple = false
    var body: some View {
        
        ZStack {
            Color(red: 0.0, green: 0.0, blue: 0.0)
                .scaleEffect(1.2)
            Image("pin")
                .scaleEffect(x: 1, y: squash_and_tretch ? 1.1 : 0.5, anchor: .bottom)
                .rotationEffect(.degrees(rotate ? 0 : 45), anchor: .bottom)
                .offset(y: jump ? 60 : -60)
                .animation(Animation.easeInOut(duration: 0.25).delay(0.5).repeatCount(1, autoreverses: true))
                .onAppear() {
                    self.squash_and_tretch.toggle()
                    
                    withAnimation(Animation.easeInOut(duration: 0.5).delay(0.2).repeatCount(1, autoreverses: true)) {
                        self.jump.toggle()
                    }
                    
                    withAnimation(Animation.interpolatingSpring(stiffness: 170, damping: 5).delay(0.3)) {
                         self.rotate.toggle()
                    }
            }
            
            Circle()
                .strokeBorder(lineWidth: displayRipple ? 1 : 5)
                .frame(width: 300, height: 300)
                .scaleEffect(displayRipple ? 1 : 0)
                .foregroundColor(.white)
                .opacity(displayRipple ? 0 : 1)
                .offset(y: 60)
                .animation(Animation.easeInOut(duration: 1).delay(0.2))
                .onAppear() {
                    self.displayRipple.toggle()
                
                    withAnimation(Animation.easeInOut(duration: 1).delay(2)) {
                         self.dismissRipple.toggle()
                    }
                    
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
