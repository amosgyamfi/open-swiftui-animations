//
//  TopNotificationView.swift
//  matched_geometry_notifications
//
//  Created by Amos Gyamfi on 10.8.2020.
//

import Foundation
import SwiftUI

struct ExpandedNoti1: View {
    var body: some View {
        VStack(alignment: .leading) {
            
            HStack(spacing: 16){
                ColorPicker("", selection: /*@START_MENU_TOKEN@*/.constant(.red)/*@END_MENU_TOKEN@*/)
                    .frame(width: 20, height: 20)
                
                Text("ColorWell")
                    .font(.headline)
                
                Spacer()
                
                Text("2 hours ago")
                    .font(.caption)
            }
            
            Text("Take it before your breakfast")
                .font(.title2)
            Text("What is your glucose value")
                .foregroundColor(.secondary)
                
        }
        .frame(width: 360, height: 91)
        .padding()
        .background(Color(.systemGray5))
        .cornerRadius(13)
    }
}






