//
//  ContentView.swift
//  yahoo_weather_onboarding
//
//  Created by Amos Gyamfi on 18.1.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    let leftPoint = Circle()
    let rightPoint = Circle()
    @State private var ascend = false
    @State private var ascendDescend = false
    @State private var descend = false
    @State private var showCurrently = false
    @State private var hideCurrently = false
    @State private var showTomorrow = false
    @State private var hideTomorrow = false
    
    var body: some View {
        ZStack {
            Image("weather")
                .resizable()
                .scaledToFill()
                .opacity(0.05)
                .background(LinearGradient(gradient: Gradient(colors: [Color.blue, Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))]), startPoint: .top, endPoint: .bottom))
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                ZStack { // Figure
                    Circle() // Path
                        .trim(from: 1/2, to: 1)
                        .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round, dash: [3, 7]))
                        .frame(width: UIScreen.main.bounds.width - 100, height: UIScreen.main.bounds.width - 100)
                        .foregroundColor(Color(#colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)))
                    
                    leftPoint
                        .frame(width: 10, height: 10)
                        .foregroundColor(Color(#colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)))
                        .offset(x: -157)
                    rightPoint
                        .frame(width: 10, height: 10)
                        .foregroundColor(Color(#colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)))
                        .offset(x: 157)
                    
                    // Sun
                    Image(systemName: "sun.max")
                        .font(.title)
                        .offset(x: -157)
                        .foregroundColor(Color(#colorLiteral(red: 0.9529411793, green: 0.6862745285, blue: 0.1333333403, alpha: 1)))
                        // Total rotation = 17 + 145 + 18 = 180°
                        .rotationEffect(.degrees(ascend ? 17 : 0))
                        .rotationEffect(.degrees(ascendDescend ? 145 : 0))
                        .rotationEffect(.degrees(descend ? 18 : 0))
                        .onAppear() {  // Keyframe 1
                            withAnimation(Animation.easeInOut(duration: 2))
                            {
                                self.ascend.toggle()
                            }
                            // Keyframe 2
                            withAnimation(Animation.easeInOut(duration: 2).delay(4))
                            {
                                self.ascendDescend.toggle()
                            }
                            // Keyframe 3
                            withAnimation(Animation.easeInOut(duration: 2).delay(8))
                                                       {
                                                           self.descend.toggle()
                                                       }
                    }
                        
                    
                    ZStack {
                        Rectangle()
                            .frame(width: 270, height: 54)
                            .cornerRadius(12)
                            .foregroundColor(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                            .opacity(0.5)
                        
                        // Toronto weather: today
                        HStack(alignment: .center, spacing: 5) {
                        Text("Currently Toronto, ON")
                        Image(systemName: "cloud.snow.fill")
                            .font(.title)
                            .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                        Text("12°C")
                        }
                    }.opacity(showCurrently ? 1 : 0)
                     .opacity(hideCurrently ? 0 : 1)
                     .offset(y: -50)
                     .onAppear() {  // Keyframe 1
                            withAnimation(Animation.easeInOut(duration: 2).delay(2))
                            {
                                self.showCurrently.toggle()
                            }
                            
                            withAnimation(Animation.easeInOut(duration: 4).delay(2))
                            {
                                self.hideCurrently.toggle()
                            }
                    }
                    
                    ZStack { // Toronto weather: tomorrow
                        Rectangle()
                            .frame(width: 270, height: 54)
                            .cornerRadius(12)
                            .foregroundColor(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                            .opacity(0.5)
            
                        HStack(alignment: .center, spacing: 5) {
                        Text("Tomorrow, Toronto, ON")
                        Image(systemName: "cloud.sleet.fill")
                            .font(.title)
                            .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                        Text("14°C")
                                }
                            }.opacity(showTomorrow ? 1 : 0)
                            .opacity(hideTomorrow ? 0 : 1)
                             .offset(y: -50)
                             .onAppear() {  // Keyframe 1
                                    withAnimation(Animation.easeInOut(duration: 4).delay(6))
                                    {
                                        self.showTomorrow.toggle()
                                    }
                                    
                                    withAnimation(Animation.easeInOut(duration: 2).delay(8))
                                    {
                                        self.hideTomorrow.toggle()
                                    }
                            }
                    
                    
                    
                }
                Text("Never miss the weather")
                    .font(.title)
                    .foregroundColor(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
