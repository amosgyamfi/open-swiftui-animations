//
//  ContentView.swift
//  current_location_animation
//
//  Created by Amos Gyamfi on 9.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var animateSmallCircle = false
    @State private var animateLargeCircle = false
    
    var body: some View {
        ZStack {
            Image("map")
            
            Circle() // Large circle: Scale and opacity animations
                .frame(width: 100, height: 100)
                .foregroundColor(Color(#colorLiteral(red: 0.1232414171, green: 0.5427253246, blue: 0.9920887351, alpha: 1)))
                .opacity(animateLargeCircle ? 0: 0.5)
                .scaleEffect(animateLargeCircle ? 1.4 : 0)
                .offset(y: -68)
                .animation(Animation.easeOut(duration: 2).delay(2).repeatForever(autoreverses: false))
                .onAppear(){
                    self.animateLargeCircle.toggle()
            }
            
            Circle() // Small circle: Scale animation
                .frame(width: 14, height: 14)
                .foregroundColor(Color(#colorLiteral(red: 0.1232414171, green: 0.5427253246, blue: 0.9920887351, alpha: 1)))
                .scaleEffect(animateSmallCircle ? 0.8 : 1.4)
                .offset(y: -68)
                .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
                .onAppear(){
                    self.animateSmallCircle.toggle()
            }
                
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
