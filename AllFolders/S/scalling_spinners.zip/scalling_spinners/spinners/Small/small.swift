//
//  small.swift
//  spinners
//
//  Created by Amos Gyamfi on 21.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct small: View {
    @State private var spinSmall = false
    var body: some View {
         HStack {
                       Circle() // Small
                       .trim(from: 1/4, to: 1)
                           .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                           .foregroundColor(Color(#colorLiteral(red: 0.6588235294, green: 0.6588235294, blue: 0.6745098039, alpha: 1)))
                           .frame(width: 16, height: 16)
                           .rotationEffect(.degrees(spinSmall ? 360 : 0))
                           .scaleEffect(spinSmall ? 1 : 0.2 )
                           .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: false))
                           .onAppear() {
                               self.spinSmall.toggle()
                       }
                    
                       Text("         - Small")
                       
                   }
    }
}

struct small_Previews: PreviewProvider {
    static var previews: some View {
        small()
    }
}
