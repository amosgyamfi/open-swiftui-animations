//
//  ContentView.swift
//  auto_record
//
//  Created by Amos Gyamfi on 26.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var autoKeyframeOn = false
    var body: some View {
        ZStack {
            Circle()
                .frame(width: 75, height: 75)
                .foregroundColor(Color(red: 1.001, green: 0.437, blue: 0.441))
            
            Circle()
                .frame(width: 75/2, height: 75/2)
                .foregroundColor(.black)
                .opacity(0.3)
                .scaleEffect(autoKeyframeOn ? 1 : 0)
                .animation(Animation.easeOut(duration: 0.9).repeatForever(autoreverses: false))
                .onAppear() {
                    self.autoKeyframeOn.toggle()
            }
            
            Circle()
            .frame(width: 75/4, height: 75/4)
            .foregroundColor(.black)
           
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
