//
//  ContentView.swift
//  syncing_spinner
//
//  Created by Amos Gyamfi on 2.1.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var spinArrow = false   // Spinning Motion
    @State private var dismissArrow = false   // Opacity 1 - 0
    @State private var displayBorder = false   // StrokeBorder (lineWidth) 64 - 5
    @State private var displayCheckmark = false  // Trimpath from 1 - 0
    
    let screenBackground = Color(red: 0.0, green: 0.0, blue: 0.0)
    let aqua = Color(red: 0.0, green: 150/255, blue: 1.0)
    let ice = Color(red: 115/255, green: 253/255, blue: 1.0)
    var body: some View {
        ZStack {
            screenBackground
                .scaleEffect(1.2)
            
            Text("Syncing Spinner")
                .font(.largeTitle)
                .foregroundColor(.white)
                .offset(y: -350)
//
            Circle()
                .strokeBorder(style: StrokeStyle(lineWidth: displayBorder ? 5 : 64))
                .frame(width: 128, height: 128)
                .foregroundColor(aqua)
                .animation(Animation.easeOut(duration: 3).speed(1.5))
                .onAppear() {
                        self.displayBorder.toggle()
                }
            
            Image(systemName: "arrow.2.circlepath")
                .font(.largeTitle)
                .foregroundColor(.white)
                .rotationEffect(.degrees(spinArrow ? 720 : -360))
                .opacity(dismissArrow ? 0 : 1)
                .animation(Animation.easeInOut(duration: 2))
                .onAppear() {
                    self.spinArrow.toggle()
                    
                    withAnimation(Animation.easeInOut(duration: 1).delay(1)) {
                        self.dismissArrow.toggle()
                    }
            }

            Path { path in
                path.move(to: CGPoint(x: 20, y: -40))
                path.addLine(to: CGPoint(x: 20, y: -40))
                path.addLine(to: CGPoint(x: 40, y: -20))
                path.addLine(to: CGPoint(x: 80, y: -60))
                
            }.trim(from: 0, to: displayCheckmark ? 1 : 0)
             .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                .foregroundColor(displayCheckmark ? ice : .white)
             .offset(x: 155, y: 450)
                .animation(Animation.interpolatingSpring(stiffness: 160, damping: 20).delay(2))
             .onAppear() {
                    self.displayCheckmark.toggle()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
