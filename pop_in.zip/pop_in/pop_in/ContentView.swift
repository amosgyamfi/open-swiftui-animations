//
//  ContentView.swift
//  Pop In
//
//  Created by Amos Gyamfi on 10.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI
struct ContentView: View {
    @State private var popIn = false
    var body: some View {
        ZStack {
            Text("Pop In Animations")
                .font(.largeTitle)
                .offset(y: -350)
            Image("skateboarder")
                //.offset(x: popIn ? 0 : 250) // From right
                //.offset(x: popIn ? 0 : -250) // From left
                //.offset(y: popIn ? 0 : -1000) // From top
                .offset(y: popIn ? 0 : 1000) // From bottom
                .scaleEffect(popIn ? 1 : 0)
               
                .animation(Animation.easeInOut(duration: 2).delay(1).repeatForever(autoreverses: false))
                .onAppear() {
                    self.popIn.toggle()
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
