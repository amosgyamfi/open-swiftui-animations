//
//  ContentView.swift
//  hourglass_loader
//
//  Created by Amos Gyamfi on 4.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI
struct ContentView: View {
    @State private var rotateRect = false
    @State private var fillRect = true
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white, Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            ZStack {
                Rectangle()
                    .frame(width: 100, height: 150)
                    .scaleEffect(x: 1, y: fillRect ? 0.05 : 1, anchor: .bottom)
                    .foregroundColor(.blue)
                    .border(Color.blue, width: 5)
                .cornerRadius(10)
                    .onAppear() {
                        withAnimation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: false).speed(0.5)) {
                            self.fillRect.toggle()
                        }
                    }
            }.rotationEffect(.degrees(rotateRect ? 0 : 15), anchor: .bottom)
                .animation(Animation.spring(response: 1, dampingFraction: 0.3, blendDuration: 0).repeatForever(autoreverses: false))
                .shadow(radius: 0.2)
                .scaleEffect(0.5)
            .onAppear() {
                self.rotateRect.toggle()
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
