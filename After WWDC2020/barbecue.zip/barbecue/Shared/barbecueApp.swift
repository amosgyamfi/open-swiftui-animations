//
//  barbecueApp.swift
//  Shared
//
//  Created by Amos Gyamfi on 8.7.2020.
//

import SwiftUI

@main
struct barbecueApp: App {
    @State private var leftVaporizes = false
    @State private var middleVaporizes = false
    @State private var rightVaporizes = false
    var body: some Scene {
        WindowGroup {
            
            HStack(alignment: .bottom)
            {
                Image("vapor_left")
                    .clipShape(Rectangle().offset(y: leftVaporizes ? 0 : 90))
                    .animation(Animation.timingCurve(0.68, -0.6, 0.32, 1.6).delay(0.1).speed(0.9).repeatForever(autoreverses: false))
                    .onAppear {
                        leftVaporizes.toggle()
                    }
                
                Image("vapor_middle")
                    .clipShape(Rectangle().offset(y: middleVaporizes ? 0 : 80))
                    .animation(Animation.timingCurve(0.68, -0.6, 0.32, 1.6).delay(0.2).speed(0.8).repeatForever(autoreverses: false))
                    .onAppear {
                        middleVaporizes.toggle()
                    }
                
                Image("vapor_right")
                    .clipShape(Rectangle().offset(y: leftVaporizes ? 0 : 45))
                    .animation(Animation.timingCurve(0.68, -0.6, 0.32, 1.6).speed(0.9).repeatForever(autoreverses: false))
                    .onAppear {
                        rightVaporizes.toggle()
                    }
                
            }.blur(radius: 20).blendMode(.saturation).offset(x: 60, y: -65)
        }
    }
}

struct barbecueApp_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
