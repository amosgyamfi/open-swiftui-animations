//
//  ContentView.swift
//  measuring_heartrate
//
//  Created by Amos Gyamfi on 21.6.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var showRate = false
    @State private var heartBeat = false
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .edgesIgnoringSafeArea(.all)
        
            Image("heart")
                .scaleEffect(heartBeat ? 1 : 1.3)
                .animation(Animation.interpolatingSpring(stiffness: 30, damping: 10).speed(1.3/2).repeatForever(autoreverses: false))
                .onAppear() {
                    self.heartBeat.toggle()
                       }
             
            Image("pulse")
                .clipShape(Rectangle().offset(x: showRate ? 0 : -125))
                .animation(Animation.interpolatingSpring(
                            stiffness: 30, damping: 10).speed(1.3).repeatForever(autoreverses: true).delay(0.2))
                .offset(x: -12)
                .onAppear() {
                    self.showRate.toggle()
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .colorScheme(.dark)
    }
}
