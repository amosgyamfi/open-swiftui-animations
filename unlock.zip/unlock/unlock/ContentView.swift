//
//  ContentView.swift
//  unlock
//
//  Created by Amos Gyamfi on 17.3.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var locked = false
    @State private var tilted = false
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 64, height: 64)
                .cornerRadius(6)
            .foregroundColor(Color(#colorLiteral(red: 0.2, green: 0.2, blue: 0.2, alpha: 1)))
            
            Capsule()
                .trim(from: locked ? 0 : 2/3, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                .frame(width: 44, height: 74)
                .foregroundColor(Color(#colorLiteral(red: 0.2, green: 0.2, blue: 0.2, alpha: 1)))
                .offset(y: -30)
                .animation(Animation.timingCurve(0.68, -0.6, 0.32, 1.6).delay(0.5).repeatCount(1, autoreverses: true))
                .onAppear() {
                    self.locked.toggle()
            }
            
        } // Whole
            .rotationEffect(.degrees(tilted ? 0 : 30))
            .animation(Animation.timingCurve(0.68, -0.6, 0.32, 1.6).delay(0.5).repeatCount(1, autoreverses: true))
            .onAppear() {
                self.tilted.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
