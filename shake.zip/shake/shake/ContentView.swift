//
//  ContentView.swift
//  shake
//
//  Created by Amos Gyamfi on 9.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var shake = false
    var body: some View {
       Image("face_id")
        .offset(x: shake ? 10 : -10)
        .animation(Animation.easeInOut(duration: 0.1).repeatForever(autoreverses: true))
        .onAppear() {
            self.shake.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
