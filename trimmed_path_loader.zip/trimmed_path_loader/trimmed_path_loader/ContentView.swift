//
//  ContentView.swift
//  trimmed_path_loader
//
//  Created by Amos Gyamfi on 26.7.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var spinGreenCircle = false
    @State var trimGreenCircle = false
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.purple, lineWidth: 4)
                .opacity(0.2)
                .frame(width: 75, height: 75)
            
            Circle()
                .trim(from: trimGreenCircle ? 0: 1/8, to: trimGreenCircle ? 1/6: 1)
                .stroke(Color.green, lineWidth: 4)
                .frame(width: 75, height: 75)
                .rotationEffect(.degrees(spinGreenCircle ? 0 : -360*4), anchor: .center)
                .animation(Animation.linear(duration: 1).repeatForever(autoreverses: false).speed(1/3))
                .onAppear() {
                        self.spinGreenCircle.toggle()
                        self.trimGreenCircle.toggle()
            }
        }
        
        
    }
}
#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
