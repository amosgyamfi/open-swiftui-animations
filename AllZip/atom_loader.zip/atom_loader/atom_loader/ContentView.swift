//
//  ContentView.swift
//  atom_loader
//
//  Created by Amos Gyamfi on 29.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var scaleRotate = false
    var body: some View {
        ZStack {Color(red: 0.0, green: 0.0, blue: 0.0)
            .scaleEffect(1.2)
            Image("atom")
                .scaleEffect(scaleRotate ? 1 : 0.4)
                .rotationEffect(.degrees(scaleRotate ? 360 : 0), anchor: .center)
                .animation(Animation.interpolatingSpring(stiffness: 60, damping: 13).repeatForever(autoreverses: true))
            //.animation(Animation.easeInOut(duration: 2).delay(0.5).repeatForever(autoreverses: true))
                .onAppear() {
                self.scaleRotate.toggle()
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
