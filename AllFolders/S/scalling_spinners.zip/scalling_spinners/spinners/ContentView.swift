//
//  ContentView.swift
//  SwiftUI Scalling Spinners for your next project. They are suitable for empty states and loading states. You may change the timing to your need.
//
//  Created by Amos Gyamfi on 21.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var spinXLarge = false
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 50) {
            Text("SwiftUI Spinners")
                .font(.largeTitle)
            HStack {
                Circle() // X-Large
                    .trim(from: 1/4, to: 1)
                    .stroke(style: StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                    .foregroundColor(Color(#colorLiteral(red: 0.6588235294, green: 0.6588235294, blue: 0.6745098039, alpha: 1)))
                    .frame(width: 40, height: 40)
                    .rotationEffect(.degrees(spinXLarge ? 360*2 : 0)) // Rotational Motion
                    .scaleEffect(spinXLarge ? 1 : 0.2 ) // Scalling Animatioin
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: false))
                    .onAppear() {
                         
                            self.spinXLarge .toggle()
                        }
                
                Text("   - X-Large")
                
            }
            
            large()
            medium()
            small()
            xsmall()
            
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
