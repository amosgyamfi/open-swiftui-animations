//
//  ContentView.swift
//  scalling_rotating_loader
//
//  Created by Amos Gyamfi on 4.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var scaleAll = false
    @State private var rotateOuter = false
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.black
                , Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            ZStack {
                
                Circle()
                .frame(width: 50, height: 50)
                .foregroundColor(.white)
                ZStack {
                    Circle()  //
                        .trim(from: 1/2, to: 4/5)
                        .stroke(style: .init(lineWidth: 3, lineCap: .round, lineJoin: .round))
                        .frame(width: 100, height: 100)
                        .foregroundColor(.white)
                    Circle()  //
                        .trim(from: 1/2, to: 4/5)
                        .stroke(style: .init(lineWidth: 3, lineCap: .round, lineJoin: .round))
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                        .rotationEffect(.degrees(180))
                    
                }
                .rotationEffect(.degrees(rotateOuter ? 360*3 : 0))
                .animation(Animation.spring(response: 0.87, dampingFraction: 0.1, blendDuration: 0.3).repeatForever(autoreverses: true))
                .onAppear() {
                    self.rotateOuter.toggle()
                }
            }.scaleEffect(scaleAll ? 1 : 0.3)
            .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: true))
            .onAppear() {
                self.scaleAll.toggle()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
