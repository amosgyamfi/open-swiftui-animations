//
//  ContentView.swift
//  blink
//
//  Created by Amos Gyamfi on 4.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var blink = false
    var body: some View {
        Image("face_id")
            .opacity(blink ? 0 : 1)
            .animation(Animation.easeInOut(duration: 0.2).delay(0.5).repeatCount(50, autoreverses: false))
            .onAppear() {
                self.blink.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
