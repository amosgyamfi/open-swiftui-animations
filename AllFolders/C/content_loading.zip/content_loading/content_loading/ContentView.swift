//
//  ContentView.swift
//  content_loading
//
//  Created by Amos Gyamfi on 12.7.2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var moveRightLeft = false
    
    let screenFrame = Color(.systemBackground)
    var body: some View {
        ZStack {
            screenFrame
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack {
                ZStack {
                    Capsule()  // Inactive
                        .frame(width: 128, height: 6, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color(.systemGray4))
                        
                    Capsule()
                        .clipShape(Rectangle().offset(x: moveRightLeft ? 80 : -80))
                        .frame(width: 100, height: 6, alignment: .leading)
                        .foregroundColor(Color(.systemBlue))
                        .offset(x: moveRightLeft ? 14 : -14)
                        .animation(Animation.easeInOut(duration: 0.5).delay(0.2).repeatForever(autoreverses: true))
                        .onAppear {
                            moveRightLeft.toggle()
                        }
                }
                
                Text("Loading...")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
