//
//  ContentView.swift
//  face_id_animation
//
//  Created by Amos Gyamfi on 15.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            ZStack {
                Rectangle()
                    .stroke(style: StrokeStyle(lineWidth:6, lineCap: .round, lineJoin: .round,  dash: [45, 50], dashPhase: 12))
                    .frame(width: 100, height: 100)
                    .foregroundColor(.blue)
                Rectangle()
                .stroke(style: StrokeStyle(lineWidth:6, lineCap: .round, lineJoin: .round,  dash: [45, 50], dashPhase: 12))
                .frame(width: 100, height: 100)
                .foregroundColor(.blue)
                .rotationEffect(.degrees(90))
                
                
                ZStack {
                    Rectangle()
                        .stroke(style: StrokeStyle(lineWidth:6, lineCap: .round, lineJoin: .round,  dash: [45, 50], dashPhase: 12))
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                    Rectangle()
                    .stroke(style: StrokeStyle(lineWidth:6, lineCap: .round, lineJoin: .round,  dash: [45, 50], dashPhase: 12))
                    .frame(width: 100, height: 100)
                    .foregroundColor(.blue)
                    .rotationEffect(.degrees(90))
                }.rotationEffect(.degrees(180))
            }
            
        } 
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
