//
//  ContentView.swift
//  scalling_squares_loader
//
//  Created by Amos Gyamfi on 2.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var topLeftOffset = false
    @State private var topRightOffset = false
    @State private var bottomLeftOffset = false
    @State private var bottomRightOffset = false
     @State private var rotateSquares = false
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white
                , Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            ZStack {
                Rectangle()  // Top left
                    .frame(width: 20, height: 20)
                    .offset(x: topLeftOffset ? -15 : 0, y: topLeftOffset ? -15 : 0)
                    .animation(Animation.easeInOut(duration: 0.6).repeatForever(autoreverses: true))
                    .onAppear() {
                    self.topLeftOffset.toggle()
                }
                Rectangle() // Top right
                    .frame(width: 20, height: 20)
                    .offset(x: topRightOffset ? 15 : 0, y: topRightOffset ? -15 : 0)
                        .animation(Animation.easeInOut(duration: 0.6).repeatForever(autoreverses: true))
                        .onAppear() {
                        self.topRightOffset.toggle()
                    }
                Rectangle() // Bottom left
                    .frame(width: 20, height: 20)
                    .offset(x: bottomLeftOffset ? -15 : 0, y: bottomLeftOffset ? 15 : 0)
                        .animation(Animation.easeInOut(duration: 0.6).repeatForever(autoreverses: true))
                        .onAppear() {
                        self.bottomLeftOffset.toggle()
                    }
                Rectangle() // Bottom right
                    .frame(width: 20, height: 20)
                    .offset(x: bottomRightOffset ? 15 : 0, y: bottomRightOffset ? 15 : 0)
                        .animation(Animation.easeInOut(duration: 0.6).repeatForever(autoreverses: true))
                        .onAppear() {
                            self.bottomRightOffset.toggle()
                    }
            }.rotationEffect(.radians(rotateSquares ? .pi : -.pi/8))
                .animation(Animation.easeInOut(duration: 0.6).repeatForever(autoreverses: true))
             .onAppear() {
                    self.rotateSquares.toggle()
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
