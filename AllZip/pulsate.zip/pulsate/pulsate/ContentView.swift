//
//  ContentView.swift
//  pulsate
//
//  Created by Amos Gyamfi on 4.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var pulsate = false
    var body: some View {
        Image("face_id")
            .scaleEffect(pulsate ? 0.5 : 1)
            .animation(Animation.easeInOut(duration: 1).delay(0).repeatCount(50, autoreverses: true))
            .onAppear() {
                self.pulsate.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

