//
//  ContentView.swift
//  audio_tweet
//
//  Created by Amos Gyamfi on 18.6.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var pulsing = false
    @State private var pulsating = false
    @State private var vibrating = false
    
    let bg = Color(.systemTeal)
        
    var body: some View {
        ZStack {
            bg
                .edgesIgnoringSafeArea(.all)
            
            Circle()
                .frame(width: 150, height: 150, alignment: .center)
                .foregroundColor(Color(.systemGray4))
                .blendMode(.softLight)
                .scaleEffect(pulsing ? 1 : 1.05, anchor: pulsing ? .topTrailing : .bottom)
                .offset(y: pulsing ? 2 : -3)
                .animation(Animation.easeIn(duration: 0.1).repeatForever(autoreverses: true))
                .onAppear(){
                    self.pulsing.toggle()
            }
            
            Circle()
                .frame(width: 150, height: 150, alignment: .center)
                .foregroundColor(Color(.systemGray4))
                .blendMode(.softLight)
                .scaleEffect(pulsating ? 1 : 1.05, anchor: pulsating ? .bottomLeading : .bottomTrailing)
                .offset(x: pulsating ? 5 : -5)
                .animation(Animation.easeOut(duration: 0.1).repeatForever(autoreverses: true))
                .onAppear(){
                    self.pulsating.toggle()
            }
            
            Image("amos")
                .scaleEffect(vibrating ? 1 : 1.05)
                .animation(Animation.easeInOut(duration: 0.1).repeatForever(autoreverses: true))
                .onAppear(){
                    self.vibrating.toggle()
            }
            
            Circle()
                .frame(width: 50, height: 50, alignment: .center)
                .blendMode(.softLight)
            
            Image(systemName: "pause.fill")
                .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                
                
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
