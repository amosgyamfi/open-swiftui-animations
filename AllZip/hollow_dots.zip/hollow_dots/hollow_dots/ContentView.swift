//
//  ContentView.swift
//  hollow_dots
//
//  Created by Amos Gyamfi on 1.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var leftAnimates = false
    @State private var middleAnimates = false
    @State private var rightAnimates = false
    
    var body: some View {
        
        
        // Middle
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white, Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            // Left
            Circle()
                .stroke(lineWidth: 3)
                .frame(width: 12, height: 12)
                .scaleEffect(leftAnimates ? 1 : 0)
                .animation(Animation.spring().repeatForever(autoreverses: false).speed(0.5))
                .offset(x: -20)
                .onAppear() {
                    self.leftAnimates.toggle()
            }
            
            Circle()
                .stroke(lineWidth: 3)
                .frame(width: 12, height: 12)
                .scaleEffect(middleAnimates ? 1 : 0)
                .animation(Animation.spring().repeatForever(autoreverses: false).speed(0.5).delay(0.15))
                .onAppear() {
                        self.middleAnimates.toggle()
                }
            
            // Right
            Circle()
                .stroke(lineWidth: 3)
                .frame(width: 12, height: 12)
                .scaleEffect(rightAnimates ? 1 : 0)
                .animation(Animation.spring().repeatForever(autoreverses: false).speed(0.5).delay(0.25))
                .offset(x: 20)
                .onAppear() {
                        self.rightAnimates.toggle()
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
