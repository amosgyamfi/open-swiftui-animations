//
//  ContentView.swift
//  Pop Out
//
//  Created by Amos Gyamfi on 10.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI
struct ContentView: View {
    @State private var popOut = true
    var body: some View {
        ZStack {
            Text("Pop Out Animations")
                .font(.largeTitle)
                .offset(y: -350)
            Image("skateboarder")
            //.offset(x: popOut ? 0 : 350) // From right
                //.offset(x: popOut ? 0 : -350) // From left
                //.offset(y: popOut ? 0 : -1000) // From top
                .offset(y: popOut ? 0 : 1000) // From bottom
                .scaleEffect(popOut ? 1 : 0) // Center
                .animation(Animation.easeInOut(duration: 2).delay(1).repeatForever(autoreverses: false))
                .onAppear() {
                    self.popOut.toggle()
            }
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
