//
//  ContentView.swift
//  CallingAnimation
//
//  Created by Amos Gyamfi on 27.9.2020.
//

import SwiftUI

struct ContentView: View {
    @State private var animateLogo = false
    @State private var animateSmaller = false
    @State private var animateMedium = false
    @State private var animateLarger = false
    var body: some View {
        VStack {
            
            VStack {
                Text("Amos Gyamfi")
                    .font(.title)
                
                Text("+35855901852")
                
                Text("Calling...")
                    .foregroundColor(Color(.systemTeal))
                    
            }
            
            ZStack {  // Animated views
                Image("background")
                .resizable()
                    .edgesIgnoringSafeArea(.all)
                
                // Circle: Larger
                Image(systemName: "heart")
                    .font(.system(size: 212 + 80))
                    .foregroundColor(Color(#colorLiteral(red: 0.4620226622, green: 0.8382837176, blue: 1, alpha: 1)))
                    .opacity(0.5)
                    .scaleEffect(animateLarger ? 1.2 : 0.5, anchor: .center)
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.6))
                    .onAppear() {
                        self.animateLarger.toggle()
                }
                
                // Circle: Medium
                Image(systemName: "heart")
                    .font(.system(size: 212 + 40))
                    .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))
                    .opacity(0.5)
                    .scaleEffect(animateMedium ? 1.2 : 0.5, anchor: .center)
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.4))
                    .onAppear() {
                        self.animateMedium.toggle()
                }
                
                
                // Circle: Smaller
                Image(systemName: "heart")
                    .font(.system(size: 212))
                    .foregroundColor(Color(#colorLiteral(red: 0, green: 0.3285208941, blue: 0.5748849511, alpha: 1)))
                    .opacity(0.5)
                    .scaleEffect(animateSmaller ? 1.2 : 0.5, anchor: .center)
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.2))
                    .onAppear() {
                        self.animateSmaller.toggle()
                }
                
                Image("amos") // Heart-shape img
                    .scaleEffect(animateLogo ? 1 : 1.4, anchor: .center)
                    .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true))
                    .onAppear() {
                        self.animateLogo.toggle()
                }
                
            } // Animated views
            
            HStack(spacing: 30) {
                
                Image(systemName: "mic.circle").font(.system(size: 48))
                
                Image(systemName: "phone.circle.fill").font(.system(size: 48)).foregroundColor(Color(.systemRed))
                
                Image(systemName: "speaker.wave.2.circle").font(.system(size: 48))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(/*@START_MENU_TOKEN@*/.dark/*@END_MENU_TOKEN@*/)
    }
}
