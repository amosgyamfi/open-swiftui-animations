//
//  ContentView.swift
//  swapping_square_spinner
//
//  Created by Amos Gyamfi on 2.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var animateBottomRight = false
    @State private var animateTopLeft = false
    @State private var animateTopRight = false
    @State private var animateBottomLeft = false
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white, Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            Rectangle() // Middle
                .frame(width:20, height: 20)
            
            Rectangle()  // Bottom right
                .frame(width:30, height: 30)
                .scaleEffect(animateBottomRight ? 1 : 0.2)
                .offset(x: animateBottomRight ? 20 : 0, y: animateBottomRight ? 20 : 0)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                .onAppear() {
                    self.animateBottomRight.toggle()
            }
            
            Rectangle() // Top left
                .frame(width:30, height: 30)
                .scaleEffect(animateTopLeft ? 1 : 0.2)
                .offset(x: animateTopLeft ? -20 : 0, y: animateTopLeft ? -20 : 0)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                    .onAppear() {
                        self.animateTopLeft.toggle()
                }
            
            Rectangle() // Top right
                .frame(width: 20, height: 20)
                .scaleEffect(animateTopRight ? 0.2 : 1.5)
                .offset(x: animateTopLeft ? 0 : 20, y: animateTopRight ? 0 : -20)
            .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                .onAppear() {
                        self.animateTopRight.toggle()
                }
            
            Rectangle() // Bottom left
                .frame(width: 20, height: 20)
                .scaleEffect(animateBottomLeft ? 0.2 : 1.5)
                    .offset(x: animateBottomLeft ? 0 : -20, y: animateBottomLeft ? 0 : 20)
                .animation(Animation.easeInOut.repeatForever(autoreverses: true).speed(0.8))
                    .onAppear() {
                            self.animateBottomLeft.toggle()
                    }
        }.foregroundColor(.pink
        )
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
