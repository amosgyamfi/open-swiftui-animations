//
//  ContentView.swift
//  notification_realistic_bell
//
//  Created by Amos Gyamfi on 25.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var bodyAnimates = false
    @State private var clapperAnimates = false
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.black, Color.black]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            
            Text("Animated Notification: Realistic Bell")
                .offset(y: -250)
                .foregroundColor(.white)
            
            Image("hinge")
                .offset(x: 0, y: -25)
                
            Image("clapper")
                .offset(x: clapperAnimates ? -7 : 15, y: clapperAnimates ? 30 : 20)
            .animation(Animation.interpolatingSpring(stiffness: 170, damping: 5).repeatForever(autoreverses: false))
                .onAppear() {
                    self.clapperAnimates.toggle()
            }
            
            Image("body")
                .rotationEffect(.degrees(bodyAnimates ? 15 : -30))
                .animation(Animation.interpolatingSpring(stiffness: 150, damping: 5).repeatForever(autoreverses: false))
                    .onAppear() {
                        self.bodyAnimates.toggle()
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
