//
//  ContentView.swift
//  hue_rotation
//
//  Created by Amos Gyamfi on 31.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var hueAdjust = false
    let screenBackground = Color(red: 0, green: 0, blue: 0)
    let ice = Color(red: 0.451, green: 0.992, blue: 1.0)
    
    var body: some View {
        ZStack {
           screenBackground // Background color
                .scaleEffect(1.2)
            
            Text("What is HUE Rotation?")
                .font(.largeTitle)
                .foregroundColor(ice)
                .offset(y: -350)
            
            Image("winter") // Load images here
                .resizable()
                .scaledToFit()
                .hueRotation(.degrees(hueAdjust ? 360*4 : 0)) // Shifts all of the colors in a view according to the angle you specify.
                .animation(Animation.easeInOut(duration: 2).delay(0.5).repeatForever(autoreverses: true))
                .onAppear() {
                    self.hueAdjust.toggle()
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
