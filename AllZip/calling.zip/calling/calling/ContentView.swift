//
//  ContentView.swift
//  calling
//
//  Created by Amos Gyamfi on 4.4.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var amosPulsing = false
    @State private var innerPulsing = false
    @State private var middlePulsing = false
    @State private var outerPulsing = false
    var body: some View {
        ZStack {
            
            RadialGradient(gradient: Gradient(colors: [Color.black
                , Color.gray]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .edgesIgnoringSafeArea(.all)
            Image("outer")
                .scaleEffect(amosPulsing ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.1))
                .onAppear() {
                        self.outerPulsing.toggle()
                }
            
            Image("middle")
                .scaleEffect(amosPulsing ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.2))
                .onAppear() {
                        self.middlePulsing.toggle()
                }
            
            Image("inner")
                .scaleEffect(amosPulsing ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.3))
                .onAppear() {
                        self.innerPulsing.toggle()
                }
            
            Image("amos")
                .scaleEffect(amosPulsing ? 1 : 1.4, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true))
                .onAppear() {
                    self.amosPulsing.toggle()
            }
            
            Text("Amos is calling")
                .foregroundColor(.white)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
