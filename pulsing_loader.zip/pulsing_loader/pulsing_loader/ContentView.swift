//
//  ContentView.swift
//  pulsing_loader
//
//  Created by Amos Gyamfi on 11.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI
struct ContentView: View {
    @State private var pulsate = false  // for small white cdircle
    @State private var progress = false  // for white ring
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white, Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            Circle() // Large circle
                .frame(width: 150, height: 150)
                .foregroundColor(.blue)
            Circle() // Ring
                .trim(from: progress ? 0 : 1, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                .frame(width: 150, height: 150)
                .foregroundColor(.white)
                .opacity(0.4)
            Circle() // Ring
                .trim(from: progress ? 0 : 1, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                .frame(width: 150, height: 150)
                .foregroundColor(.white)
                .rotationEffect(.degrees(90))
                .rotation3DEffect(.degrees(180), axis: (x: 1, y: 0, z: 0))
                .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: false))
                .onAppear() {
                    self.progress.toggle()
            }
            Circle() // small circle
                .frame(width: 40, height: 40)
                .foregroundColor(.white)
                .scaleEffect(pulsate ? 1 : 0.6)
                .animation(Animation.spring(response: 0.3, dampingFraction: 0.2, blendDuration: 0).repeatForever(autoreverses: false))
                .onAppear() {
                    self.pulsate.toggle()
            }
        }.shadow(radius: 25)
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
