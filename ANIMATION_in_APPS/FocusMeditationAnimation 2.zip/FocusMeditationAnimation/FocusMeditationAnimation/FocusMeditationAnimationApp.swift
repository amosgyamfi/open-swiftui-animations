//
//  FocusMeditationAnimationApp.swift
//  FocusMeditationAnimation
//
//  Created by Amos Gyamfi on 8.2.2021.
//

import SwiftUI

@main
struct FocusMeditationAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
