//
//  content_loadingApp.swift
//  content_loading
//
//  Created by Amos Gyamfi on 12.7.2020.
//

import SwiftUI

@main
struct content_loadingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
