//
//  ContentView.swift
//  jump-in_animations
//
//  Created by Amos Gyamfi on 23.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var jumpIn = false
    var body: some View {
        ZStack {
            Text("Jump-In Animations")
                .font(.largeTitle)
                .offset(y: -350)
            Image("face_id")
                .scaleEffect(jumpIn ? 1 : 0)
                .rotationEffect(.degrees(jumpIn ? 0 : 120), anchor: .center)
                .animation(Animation.interpolatingSpring(mass: 0.5, stiffness: 200, damping: 5, initialVelocity: 0).delay(0.5).speed(0.5).repeatForever(autoreverses: false))
                .onAppear() {
                    self.jumpIn.toggle()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
