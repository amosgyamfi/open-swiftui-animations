//
//  ContentView.swift
//  skype_calling
//
//  Created by Amos Gyamfi on 9.4.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var animateLogo = false
    @State private var animateSmaller = false
    @State private var animateMedium = false
    @State private var animateLarger = false
    var body: some View {
        ZStack {
            Image("background")
            .resizable()
                .edgesIgnoringSafeArea(.all)
            
            // Circle: Larger
            Circle()
                .frame(width: 212+80, height: 212+80)
                .foregroundColor(Color(#colorLiteral(red: 0.4620226622, green: 0.8382837176, blue: 1, alpha: 1)))
                .opacity(0.5)
            .scaleEffect(animateLarger ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.3))
                .onAppear() {
                    self.animateLarger.toggle()
            }
            
            // Circle: Medium
            Circle()
                .frame(width: 212+40, height: 212+40)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))
                .opacity(0.5)
                .scaleEffect(animateMedium ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.2))
                .onAppear() {
                    self.animateMedium.toggle()
            }
            
            
            // Circle: Smaller
            Circle()
                .frame(width: 212, height: 212)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.3285208941, blue: 0.5748849511, alpha: 1)))
                .opacity(0.5)
                .scaleEffect(animateSmaller ? 1.2 : 0.5, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true).delay(0.1))
                .onAppear() {
                    self.animateSmaller.toggle()
            }
            
            
            Image("skype-logo")
                .scaleEffect(animateLogo ? 1 : 1.4, anchor: .center)
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true))
                .onAppear() {
                    self.animateLogo.toggle()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
