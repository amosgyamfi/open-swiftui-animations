//
//  ContentView.swift
//  spring_animation_silent_mode_off
//
//  Created by Amos Gyamfi on 29.1.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var hideFromScreen = false
    @State private var inertialRotate = false
    @State private var onOff = false
    @State private var offOn = false
    @State private var hideSlash = false
    @State private var silenceColorOff = false
    var body: some View {
        ZStack {
            Color(red: 0, green: 0, blue: 0)
                .edgesIgnoringSafeArea(.all)
            Text("Spring Animation: Silent Mode Off")
            
            ZStack {
                Rectangle()
                    .frame(width: 256, height: 64)
                    .cornerRadius(30)
                    .foregroundColor(Color(#colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)))
                    
                
                HStack(spacing: 30) {
                    ZStack {
                        Image(systemName: "bell.fill")
                            .font(.largeTitle)
                            .rotationEffect(.degrees(inertialRotate ? 0 : -25), anchor: .top)
                            .foregroundColor(silenceColorOff ? .gray: .red)
                            .onAppear()
                                {
                                    withAnimation(Animation.easeOut(duration: 0.5).delay(2.3)) {
                                    self.silenceColorOff.toggle()
                                                                                        }
                                
                                withAnimation(Animation.interpolatingSpring(stiffness: 350, damping: 3).delay(2.3)) {
                                    self.inertialRotate.toggle()
                                }
                                
                               
                        }
                        
                        Rectangle()  // Bell slash
                            .frame(width: 5, height: 45)
                            .foregroundColor(Color(#colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)))
                            .border(Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)))
                            .scaleEffect(x: 1, y: hideSlash ? 0 : 1, anchor: .topLeading)
                            .rotationEffect(.degrees(-45))
                            .onAppear() {
                                withAnimation(Animation.easeOut(duration: 0.8).delay(2.1))
                                {
                                self.hideSlash.toggle()
                                }
                        }
                    }
                    VStack {
                        Text("Silent Mode")
                            .foregroundColor(Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)))
                        ZStack {
                            Text("Off")
                                .foregroundColor(Color(#colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)))
                                .opacity(offOn ? 1 : 0)
                                .onAppear() {
                                        withAnimation(Animation.easeOut(duration: 1.2).delay(2.5))
                                        {
                                        self.offOn.toggle()
                                        }
                                }
                            
                            Text("On")
                                .foregroundColor(Color(#colorLiteral(red: 0.521568656, green: 0.1098039225, blue: 0.05098039284, alpha: 1)))
                                .opacity(onOff ? 0 : 1)
                                .onAppear() {
                                    withAnimation(Animation.easeOut(duration: 1.2).delay(2.1))
                                    {
                                    self.onOff.toggle()
                                    }
                            }
                            
                        }
                    }
                }
            }.offset(y: hideFromScreen ? -UIScreen.main.bounds.height/2.6 : -UIScreen.main.bounds.height/1.85 )
                .animation(Animation.easeOut(duration: 0.5).delay(2))
                .onAppear() {
                    self.hideFromScreen.toggle()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
