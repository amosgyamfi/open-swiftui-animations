//
//  ContentView.swift
//  pulsate
//
//  Created by Amos Gyamfi on 3.8.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State var pulsate = false
    
    var body: some View {
        Image(systemName: "circle")
            .scaleEffect(pulsate ? 3 : 0)
            .opacity(pulsate ? 0 : 1 )
            .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: false))
            .onAppear() {
                self.pulsate.toggle()
        }
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
