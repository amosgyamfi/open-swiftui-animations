//
//  photo_zoomApp.swift
//  photo_zoom
//
//  Created by Amos Gyamfi on 8.8.2020.
//

import SwiftUI

@main
struct photo_zoomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
