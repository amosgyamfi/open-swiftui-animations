//
//  ContentView.swift
//  activity_loader
//
//  Created by Amos Gyamfi on 5.8.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var rotateHexagon = false
    @State var scaleCircle = false
    
    var body: some View {
        VStack {
            ZStack {
                Circle()
                    .frame(width: 100, height: 100)
                    .foregroundColor(scaleCircle ? .blue : .green)
                    .scaleEffect(scaleCircle ? 1 : 0)
                    .animation(Animation.easeOut(duration: 1).repeatForever().delay(2))
                    .onAppear() {
                            self.scaleCircle.toggle()
                    }
                
                Image("hexagon")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .rotationEffect(.degrees(rotateHexagon ? 0 : -60), anchor: .center)
                    .frame(width: 60, height: 60)
                    .animation(Animation.timingCurve(0.19, 1, 0.22, 1, duration: 2).repeatForever(autoreverses: false))
                    .onAppear() {
                        self.rotateHexagon.toggle()
                        
                
                }
                
                
            }
            
            Text("Waiting for next activity to begin...")
        }
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
