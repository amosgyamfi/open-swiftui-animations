//
//  medium.swift
//  spinners
//
//  Created by Amos Gyamfi on 21.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct medium: View {
    @State private var spinMedium = false
    var body: some View {
        HStack {
            Circle() // Medium
            .trim(from: 1/4, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 3, lineCap: .round, lineJoin: .round))
                .foregroundColor(Color(#colorLiteral(red: 0.6588235294, green: 0.6588235294, blue: 0.6745098039, alpha: 1)))
                .frame(width: 24, height: 24)
                .rotationEffect(.degrees(spinMedium ? 360 : 0))
                .scaleEffect(spinMedium ? 1 : 0.2 )
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: false))
                .onAppear() {
                self.spinMedium.toggle()
            }
         
            Text("       - Medium")
            
        }
    }
}

struct medium_Previews: PreviewProvider {
    static var previews: some View {
        medium()
    }
}
