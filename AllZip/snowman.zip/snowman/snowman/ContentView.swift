//
//  ContentView.swift
//  snowman
//
//  Created by Amos Gyamfi on 23.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var blinkLeftEye = false
    @State private var blinkRightEye = false
    var body: some View {
        ZStack {
            
            Circle()
                .frame(width: 200, height: 200)
                .foregroundColor(Color(red: 0.189, green: 0.187, blue: 0.256))
            
            Circle()
                .trim(from: 3/4, to: 1)
                .frame(width: 200, height: 200)
                .foregroundColor(.white)
                .rotationEffect(.degrees(135))
                .offset(y: 1)
            
            // Snow
            Circle()
                .frame(width: 20, height: 20)
                .foregroundColor(.white)
                .rotationEffect(.degrees(135))
                .offset(x: 60, y: 65)
            Circle()
                .frame(width: 20, height: 20)
                .foregroundColor(.white)
                .rotationEffect(.degrees(135))
                .offset(x: -60, y: 65)
            Circle()
                .frame(width: 20, height: 20)
                .foregroundColor(.white)
                .rotationEffect(.degrees(135))
                .offset(x: -45, y: 68)
            Circle()
                .frame(width: 20, height: 20)
                .foregroundColor(.white)
                .rotationEffect(.degrees(135))
                .offset(x: 45, y: 68)
            
            // Snowman
            ZStack {
                Circle()
                    .frame(width: 83, height: 83)
                    .foregroundColor(.white)
                    .rotationEffect(.degrees(135))
                    .offset(y: 45)
                
                Circle() // Head
                    .frame(width: 50, height: 50)
                    .foregroundColor(.white)
                    .rotationEffect(.degrees(135))
                    .offset(y: -20)
                
                Circle() // Buttons
                    .frame(width: 5, height: 5)
                    .foregroundColor(.black)
                    .rotationEffect(.degrees(135))
                    .offset(x: -10, y: 30)
                Circle()
                    .frame(width: 5, height: 5)
                    .foregroundColor(.black)
                    .rotationEffect(.degrees(135))
                    .offset(x: -10, y: 40)
                
                // Eyes
                ZStack {
                    Circle()  // Left eye
                        .frame(width: 5, height: 5)
                        .foregroundColor(.black)
                        .rotationEffect(.degrees(135))
                        .scaleEffect(x: 1, y: blinkLeftEye ? 0.2 : 0.8, anchor: .center)
                        .offset(x: 2, y: -25)
                        .animation(Animation.easeInOut(duration: 0.1).delay(1).repeatForever(autoreverses: false))
                        .onAppear() {
                            self.blinkLeftEye.toggle()
                    }
                    
                    Circle() // Right eye
                        .frame(width: 5, height: 5)
                        .foregroundColor(.black)
                        .rotationEffect(.degrees(135))
                        .scaleEffect(x: 1, y: blinkRightEye ? 0.1 : 0.8, anchor: .center)
                        .offset(x: -12, y: -25)
                        .animation(Animation.easeOut(duration: 0.1).delay(1).repeatForever(autoreverses: false))
                        .onAppear() {
                            self.blinkRightEye.toggle()
                    }
                    
                    Circle()  // Mouth
                        .trim(from: 3/4, to: 1)
                        .stroke(lineWidth: 1)
                        .frame(width: 20, height: 20)
                        .foregroundColor(Color(red: 0.249, green: 0.241, blue: 0.337))
                        .rotationEffect(.degrees(135), anchor: .center)
                        .offset(x: -7, y: -20)
                    
                    // Hands
                    Circle()
                        .frame(width: 20, height: 20)
                        .foregroundColor(.white)
                        .rotationEffect(.degrees(135))
                        .shadow(radius: 5)
                        .offset(x: 40, y: 30)
                    Circle()
                        .frame(width: 20, height: 20)
                        .foregroundColor(.white)
                        .rotationEffect(.degrees(135))
                        .shadow(radius: 5)
                        .offset(x: -40, y: 30)
                }
                
                Rectangle() // Tie
                    .frame(width: 40, height: 6)
                    .foregroundColor(.red)
                    .cornerRadius(2)
                    .offset(y: 3)
                Rectangle() // Tie
                    .frame(width: 45, height: 6)
                    .foregroundColor(.red)
                    .cornerRadius(2)
                    .rotationEffect(.degrees(105), anchor: .leading)
                    .offset(x: 10, y: 3)
                
                // Cap
               Capsule()
                    .trim(from: 1/2, to: 1)
                    .frame(width: 20, height: 30)
                    .cornerRadius(10)
                    .foregroundColor(.red)
                    .cornerRadius(10)
                    .rotationEffect(.degrees(15), anchor: .center)
                    .offset(x: 10, y: -35)
                Circle()
                    .frame(width: 8, height: 8)
                    .cornerRadius(10)
                    .foregroundColor(.red)
                    .offset(x: 17, y: -48)
            }
            
            
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
