//
//  LikeThumbUpApp.swift
//  LikeThumbUp
//
//  Created by Amos Gyamfi on 14.8.2020.
//

import SwiftUI

@main
struct LikeThumbUpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
