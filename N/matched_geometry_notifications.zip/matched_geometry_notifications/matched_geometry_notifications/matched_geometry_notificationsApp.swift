//
//  matched_geometry_notificationsApp.swift
//  matched_geometry_notifications
//
//  Created by Amos Gyamfi on 10.8.2020.
//

import SwiftUI

@main
struct matched_geometry_notificationsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
