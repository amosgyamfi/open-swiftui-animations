//
//  ContentView.swift
//  touch_id
//
//  Created by Amos Gyamfi on 19.6.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var isOk = false
    var body: some View {
        VStack {
            ZStack {
                Image("finger1")
                Image("finger2")
                    .clipShape(
                        Rectangle()
                            .offset(y: isOk ? 0 : 90))
                    .hueRotation(.degrees(isOk ? 360 : 0))
                    
                    // Multiply, Luminosity, PlusDarker
                    //.blendMode(isOk ? .multiply: .plusDarker)
                    //.blendMode(isOk ? .luminosity: .plusDarker)
                    //.blendMode(isOk ? .plusDarker: .multiply)
                    .blendMode(isOk ? .plusDarker: .luminosity)
                    .animation(Animation.linear(duration: 1).delay(1))
                    .onAppear(){
                        self.isOk.toggle()
                }
                    
            }
            Text("Confirm with Touch ID")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
