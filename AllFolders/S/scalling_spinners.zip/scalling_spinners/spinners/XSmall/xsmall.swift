//
//  xsmall.swift
//  spinners
//
//  Created by Amos Gyamfi on 21.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct xsmall: View {
    @State private var spinXSmall = false
    var body: some View {
       HStack {
            Circle() // X-Small
                .trim(from: 1/4, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 1, lineCap: .round, lineJoin: .round))
                .foregroundColor(Color(#colorLiteral(red: 0.6588235294, green: 0.6588235294, blue: 0.6745098039, alpha: 1)))
                .frame(width: 12, height: 12)
                .rotationEffect(.degrees(spinXSmall ? 360 : 0))
                .scaleEffect(spinXSmall ? 1 : 0.2 )
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: false))
                .onAppear() {
                    self.spinXSmall.toggle()
            }
         
            Text("          - X-Small")
        }
    }
}

struct xsmall_Previews: PreviewProvider {
    static var previews: some View {
        xsmall()
    }
}
