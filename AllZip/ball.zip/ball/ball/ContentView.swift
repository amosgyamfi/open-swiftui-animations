//
//  ContentView.swift
//  ball
//
//  Created by Amos Gyamfi on 4.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var fall = false
    var body: some View {
        Image("face_id")
            .offset(x: fall ? 0 : -300)
            .animation(Animation.spring(response: 0.4, dampingFraction: 0.5, blendDuration: 0).repeatCount(2, autoreverses: false))
            .onAppear() {
                self.fall.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
