//
//  ContentView.swift
//  Seamlessly Looping Animation
//
//  Created by Amos Gyamfi on 15.2.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var moving = false
    @State private var tilting = false
    @State private var jerking = false
    @State private var nodding = false
    @State private var blinking = false
    var body: some View {
        ZStack {
            Color(#colorLiteral(red: 0.1767325997, green: 0.4058464766, blue: 0.95100528, alpha: 1))
                .edgesIgnoringSafeArea(.all)
            ZStack { // Duck
                Image("body")
                
                ZStack { // Head, eye, beak
                    Image("beak_upper")
                        .offset(x: 53, y: -40)
                    Image("beak_lower")
                        .offset(x: 55, y: -40)
                    Image("head")
                        .offset(x: 20, y: -40)
                    
                    Image("eye") // Eye blinking animation
                        .scaleEffect(x: 1, y: blinking ? 0.1 : 1.1, anchor: .center)
                        .offset(x: 30, y: -48)
                        .animation(Animation.easeInOut(duration: 0.1).repeatForever(autoreverses: false))
                         .onAppear() {
                                self.blinking.toggle()
                        }
                // Rotate head group
                }.rotationEffect(.degrees(nodding ? 5 : -3), anchor: .leading)
                .animation(Animation.easeInOut(duration: 0.7).repeatForever(autoreverses: true))
                 .onAppear() {
                        self.nodding.toggle()
                        
                }
                
                Image("wing")
                    .offset(y: 15)
                
            }
            .rotationEffect(.degrees(tilting ? -20 : 15))
            .offset(y: jerking ? -10 : 10)
            .animation(Animation.easeInOut(duration: 0.7).delay(0.1).repeatForever(autoreverses: true))
             .onAppear() {
                    self.tilting.toggle() // rotational motion
                    self.jerking.toggle() // up & down motion
            }
            
            Image("waves") // Waves linear motion
                .offset(x: moving ? -UIScreen.main.bounds.width : UIScreen.main.bounds.width, y: 430)
                .animation(Animation.linear(duration: 5).repeatForever(autoreverses: false))
                .onAppear() {
                    self.moving.toggle()
            }
            Text("Seamlessly Looping Animation")
                .bold()
                .foregroundColor(.white)
                .offset(y: -UIScreen.main.bounds.height/3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
