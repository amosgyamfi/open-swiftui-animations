//
//  ContentView.swift
//  matched_geometry_notifications
//
//  Created by Amos Gyamfi on 10.8.2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var showBasicView = true
    @Namespace private var morphSeamlessly
    
    var body: some View {
        ZStack{
        
        if showBasicView{
            HStack{  // Container: Clear All
                Text("Notification Center")
                    .font(.title)
                
                Spacer()
                
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
            }
            .padding()
            .offset(y: -200)
            
            VStack {  // Basic view
                
                // Container: Cards
                ZStack{
                    BottomNotificationView()  // Bottom card
                    TopNotificationView()  // Top card
                    
                }
                .onTapGesture(count: 1, perform: {
                    withAnimation(
                        Animation.interpolatingSpring(stiffness: 150, damping: 30)
                    ){
                        showBasicView.toggle()
                    }
                })
            }
            .matchedGeometryEffect(id: "morph", in: morphSeamlessly)
            .offset(y: showBasicView ? -88 : 0)
            
        }
        else{
            
            HStack{  // Container: Clear All (static)
                Text("Notification Center")
                    .font(.title)
                
                Spacer()
                
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
            }
            .padding()
            .offset(y: -200)
            
            VStack {  // Detailed View
                
                HStack{  // Container: Show or Clear
                
                    
                    Text("ColorWell")
                    
                    Spacer()
                    
                    HStack {
                        Image(systemName: "chevron.up")
                        Text("Show less")
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 7)
                    .background(Color(.systemGray6))
                    .cornerRadius(26)
                    .onTapGesture(count: 1, perform: {
                        withAnimation(
                            Animation.interpolatingSpring(stiffness: 150, damping: 30)
                        ){
                            showBasicView.toggle()
                        }
                    })
                    
                    Image(systemName: "xmark.circle.fill")
                        .font(.title)
                }
                //.padding(.top, -10)
                .padding(.horizontal)
                
                ExpandedNoti1()
                ExpandedNoti2()
            
            } // End of Detailed View
            .matchedGeometryEffect(id: "morph", in: morphSeamlessly)
            //.offset(y: showBasicView ? -6.31 : 0)
            //.offset(y: -6.31)
            
        } // End of else statement
        
        } // Parent container
       
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}
