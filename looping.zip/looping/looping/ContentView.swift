//
//  ContentView.swift
//  looping
//
//  Created by Amos Gyamfi on 23.7.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    //Set initial state of animation
    @State var waveMoving = false
    @State var duckSwimming = false
    
    var body: some View {
        ZStack {
            Image("wave")
                .offset(x: waveMoving ? -600 : 600)
                //Play the animation without gesture
                .animation(Animation.linear(duration: 4).repeatForever(autoreverses: false))
                .onAppear() {
                    self.waveMoving.toggle()
            }
            
            Image("duck")
                .scaleEffect(0.5, anchor: .center)
                .rotationEffect(.degrees(duckSwimming ? -10 : 15), anchor: .center)
                .offset(y: duckSwimming ? 0 : -20)
                //Play the animation without gesture
                .animation(Animation.linear(duration: 0.3).repeatForever(autoreverses: true))
                .onAppear() {
                                    self.duckSwimming.toggle()
                            }
                
        }
    }
}

#if DEBUG
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
