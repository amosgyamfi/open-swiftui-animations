//
//  ContentView.swift
//  wavy_circle_loader
//
//  Created by Amos Gyamfi on 8.6.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State private var oneMoves = false
    @State private var twoMoves = false
    @State private var threeMoves = false
    @State private var fourMoves = false
    @State private var fiveMoves = false
    @State private var sixMoves = false
    @State private var sevenMoves = false
    @State private var eightMoves = false
    @State private var nineMoves = false
    @State private var tenMoves = false
    
    var body: some View {
        ZStack {
            Color(red: 0.0, green: 0.0, blue: 0.0)
                .edgesIgnoringSafeArea(.all)
            
            Text("Wavy Circular Loader")
                .font(.title)
                .foregroundColor(Color(#colorLiteral(red: 0.4620226622, green: 0.8382837176, blue: 1, alpha: 1)))
                .offset(y: -300)
            ZStack {
                Circle() // One
                    .stroke(lineWidth: 5)
                    .frame(width: 20, height: 20)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: oneMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true))
                    .onAppear() {
                        self.oneMoves.toggle()
                }
                
                Circle()  // Two
                    .stroke(lineWidth: 5)
                    .frame(width: 50, height: 50)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: twoMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.1))
                    .onAppear() {
                        self.twoMoves.toggle()
                }
                
                Circle()  // Three
                    .stroke(lineWidth: 5)
                    .frame(width: 80, height: 80)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: threeMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.2))
                    .onAppear() {
                        self.threeMoves.toggle()
                }
                
                Circle()  // Four
                    .stroke(lineWidth: 5)
                    .frame(width: 110, height: 110)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: fourMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.3))
                    .onAppear() {
                        self.fourMoves.toggle()
                }
                
                Circle()  // Five
                    .stroke(lineWidth: 5)
                    .frame(width: 140, height: 140)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: fiveMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.4))
                    .onAppear() {
                        self.fiveMoves.toggle()
                }
                
                Circle()  // Six
                    .stroke(lineWidth: 5)
                    .frame(width: 170, height: 170)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: sixMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.5))
                    .onAppear() {
                        self.sixMoves.toggle()
                }
                
                Circle()  // Seven
                    .stroke(lineWidth: 5)
                    .frame(width: 200, height: 200)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: sevenMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.6))
                    .onAppear() {
                        self.sevenMoves.toggle()
                }
                
                Circle()  // Eight
                    .stroke(lineWidth: 5)
                    .frame(width: 230, height: 230)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: eightMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.7))
                    .onAppear() {
                        self.eightMoves.toggle()
                }
                
                Circle()  // Nine
                    .stroke(lineWidth: 5)
                    .frame(width: 260, height: 260)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: nineMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.8))
                    .onAppear() {
                        self.nineMoves.toggle()
                }
                
                Circle()  // Ten
                    .stroke(lineWidth: 5)
                    .frame(width: 290, height: 290)
                    .foregroundColor(.white)
                    .rotation3DEffect(.degrees(75), axis: (x: 1, y: 0, z: 0))
                    .offset(y: tenMoves ? -150 : 150)
                    .animation(Animation.easeInOut(duration: 1.5).repeatForever(autoreverses: true).delay(0.9))
                    .onAppear() {
                        self.tenMoves.toggle()
                }
            
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
