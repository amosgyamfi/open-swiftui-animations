//
//  ContentView.swift
//  hitLeft
//
//  Created by Amos Gyamfi on 8.12.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI
struct ContentView: View {
    @State private var hitLeft = false
    var body: some View {
        Image("face_id")
            .rotationEffect(.degrees(hitLeft ? 30 : 0), anchor: .bottomTrailing)
            // Using custom easing easeInOutBack: cubic-bezier(0.68, -0.55, 0.265, 1.55)
            .animation(Animation.timingCurve(0.68, -0.55, 0.265, 1.55).delay(1).repeatForever(autoreverses: true))
            .onAppear() {
                self.hitLeft.toggle()
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
