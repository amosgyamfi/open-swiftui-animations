//
//  ContentView.swift
//  radar
//
//  Created by Amos Gyamfi on 30.10.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//
import SwiftUI

struct ContentView: View {
    @State var rotateOuter = false
    @State var rotateInner = false
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [Color.white, Color.blue]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                .scaleEffect(1.2)
            Image("outer") // Outer image
                .rotationEffect(.degrees(rotateInner ? -180 : 0))
                .animation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true))
                .onAppear() {
                    self.rotateOuter.toggle()
                }
            Image("inner") // Inner image
                .rotationEffect(.degrees(rotateInner ? 180 : 0))
                .animation(Animation.easeOut(duration: 1).repeatForever(autoreverses: true))
                .onAppear(){
                    self.rotateInner.toggle()
            }
        
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
