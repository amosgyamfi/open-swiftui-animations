//
//  ContentView.swift
//  gTranslate_voice_recording
//
//  Created by Amos Gyamfi on 18.11.2019.
//  Copyright © 2019 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var animateBigCircle = false
    @State private var animateSmallCircle = false
    var body: some View {
    
            VStack {
                Text("Kuunnellaan...")
                //Spacer()
                ZStack {
                    Circle()  // Big circle
                        .stroke()
                        .frame(width: 340, height: 340)
                        .foregroundColor(.gray)
                        .scaleEffect(animateBigCircle ? 1 : 0.3)
                        .opacity(animateBigCircle ? 0 : 1)
                        .animation(Animation.easeInOut(duration: 2).repeatForever(autoreverses: false))
                        .onAppear(){
                            self.animateBigCircle.toggle()
                    }
                    Circle() //Gray
                        .foregroundColor(Color(red: 0.905, green: 0.91, blue: 0.91))
                      .frame(width: 150, height: 150)
                        .scaleEffect(animateSmallCircle ? 0.9 : 1.1)
                      .animation(Animation.easeInOut(duration: 0.4).repeatForever(autoreverses: false))
                      .onAppear(){
                                self.animateSmallCircle.toggle()
                        }
                    
                    Circle() // Red
                        .frame(width: 72, height: 72)
                        .foregroundColor(.red)
                    Capsule()
                        .frame(width: 12, height: 24)
                        .foregroundColor(.white)
                        .offset(y: -5)
                    Capsule()
                    .trim(from: 1/2, to: 1)
                        .stroke(lineWidth: 3)
                        .frame(width: 22, height: 24)
                        .rotationEffect(.degrees(180))
                        .foregroundColor(.white)
                        .offset(y: -2)
                    Rectangle()
                        .frame(width: 4, height: 6)
                        .foregroundColor(.white)
                        .offset(y: 14)
                    Image(systemName: "xmark")
                        .foregroundColor(.gray)
                        .offset(x: -170, y: 60)
                    Text("Suomi")
                        .foregroundColor(.gray)
                        .offset(y: 58)
                }.offset(y: 300)
            }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
